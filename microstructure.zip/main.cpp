#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <cstdint>
#include <algorithm>
#include <iomanip>
#include <string>
#include <chrono>
#include <atomic>

#ifdef _OPENMP
#include <omp.h>
#endif

struct MertensDrift4D {
    double cumulative_x = 0.0;
    double cumulative_y = 0.0;
    double cumulative_z = 0.0;
    double cumulative_w = 0.0;

    double compute_net_displacement() const {
        return std::sqrt(cumulative_x * cumulative_x + 
                         cumulative_y * cumulative_y + 
                         cumulative_z * cumulative_z + 
                         cumulative_w * cumulative_w);
    }
};

struct QuadStep {
    double dx, dy, dz, dw;
};

bool fast_decompose_four_square(uint64_t p, int16_t& a, int16_t& b, int16_t& c, int16_t& d) {
    if (p == 2) { a = 1; b = 1; c = 0; d = 0; return true; }
    
    uint64_t limit_a = static_cast<uint64_t>(std::sqrt(p));
    for (uint64_t ta = limit_a; ta > 0; --ta) {
        uint64_t rem_a = p - (ta * ta);
        uint64_t limit_b = static_cast<uint64_t>(std::sqrt(rem_a));
        
        for (uint64_t tb = limit_b; tb >= ta; --tb) { 
            uint64_t rem_b = rem_a - (tb * tb);
            uint64_t tc = static_cast<uint64_t>(std::sqrt(rem_b));
            
            while (tc > 0) {
                uint64_t rem_c = rem_b - (tc * tc);
                uint64_t td = static_cast<uint64_t>(std::sqrt(rem_c));
                if (ta * ta + tb * tb + tc * tc + td * td == p) {
                    int16_t coords[4] = { static_cast<int16_t>(ta), static_cast<int16_t>(tb), 
                                          static_cast<int16_t>(tc), static_cast<int16_t>(td) };
                    std::sort(coords, coords + 4, std::greater<int16_t>());
                    a = coords[0]; b = coords[1]; c = coords[2]; d = coords[3];
                    return true;
                }
                --tc;
            }
        }
    }
    return false;
}

std::vector<uint64_t> generate_high_range_primes(uint64_t limit) {
    std::vector<bool> is_prime(limit + 1, true);
    std::vector<uint64_t> primes;
    if (limit >= 2) primes.reserve(limit / std::log(limit)); 
    if (limit >= 2) primes.push_back(2);
    for (uint64_t i = 3; i * i <= limit; i += 2) {
        if (is_prime[i]) {
            for (uint64_t j = i * i; j <= limit; j += i * 2)
                is_prime[j] = false;
        }
    }
    for (uint64_t i = 3; i <= limit; i += 2) {
        if (is_prime[i]) primes.push_back(i);
    }
    return primes;
}

int main() {
    const std::vector<double> zeta_gammas = {
        14.1347251417, 21.0220396388, 25.0108575801, 30.4248761259, 32.9350615877,
        37.5861781588, 40.9187190121, 43.3270732809, 48.0051508814, 49.7738324777,
        52.9703214777, 56.4462476971, 59.3470440026, 60.8317785246, 65.1125440481,
        67.0798105295, 69.5464017112, 72.0671576744, 75.7046906991, 77.1448400689,
        79.3373750202, 82.9103808541, 84.7354929808, 87.4252746138, 88.8091112076,
        92.4918992705, 94.6513440412, 95.8706342282, 98.8311942182, 101.3178510038
    };
    
    uint64_t upper_bound_limit = 1000000; 
    std::cout << "[SYSTEM] Initializing Eratosthenes Sieve fields..." << std::endl;
    std::vector<uint64_t> test_primes = generate_high_range_primes(upper_bound_limit); 
    size_t total_primes = test_primes.size();
    
    std::cout << "[SYSTEM] Found " << total_primes << " primes up to " << upper_bound_limit << "." << std::endl;
    
    std::vector<double> results_std_drift(total_primes, 0.0);
    std::vector<double> results_opt_drift(total_primes, 0.0);
    std::vector<double> results_bound(total_primes, 0.0);
    std::vector<std::string> results_status(total_primes, "SAFE");

    std::atomic<size_t> progress_counter(0);
    auto start_time = std::chrono::high_resolution_clock::now();

    std::cout << "[SYSTEM] Launching 384-Hyperoctahedral Optimization Matrix..." << std::endl;

    #pragma omp parallel
    {
        MertensDrift4D thread_standard_drift;
        MertensDrift4D thread_optimized_drift;

        #pragma omp for schedule(guided)
        for (size_t idx = 0; idx < total_primes; ++idx) {
            uint64_t p = test_primes[idx];
            int16_t a = 0, b = 0, c = 0, d = 0;
            
            if (fast_decompose_four_square(p, a, b, c, d)) {
                double log_p = std::log(static_cast<double>(p));
                double sum_cos = 0.0, sum_sin = 0.0;
                
                for (double gamma : zeta_gammas) {
                    sum_cos += std::cos(gamma * log_p);
                    sum_sin += std::sin(gamma * log_p);
                }
                double phase_r = sum_cos / zeta_gammas.size();
                double phase_i = sum_sin / zeta_gammas.size();
                
                thread_standard_drift.cumulative_x += a * phase_r;
                thread_standard_drift.cumulative_y += b * phase_i;
                thread_standard_drift.cumulative_z += c * phase_r;
                thread_standard_drift.cumulative_w += d * phase_i;
                
                int16_t perm[4] = { a, b, c, d };
                std::sort(perm, perm + 4);
                
                std::vector<QuadStep> unique_perms;
                unique_perms.reserve(24);
                do {
                    unique_perms.push_back({
                        static_cast<double>(perm[0]) * phase_r,
                        static_cast<double>(perm[1]) * phase_i,
                        static_cast<double>(perm[2]) * phase_r,
                        static_cast<double>(perm[3]) * phase_i
                    });
                } while (std::next_permutation(perm, perm + 4));
                
                double best_sq_displacement = 1e300;
                QuadStep best_step = { 0.0, 0.0, 0.0, 0.0 };
                
                for (const auto& candidate : unique_perms) {
                    for (uint32_t mask = 0; mask < 16; ++mask) {
                        double sx = (mask & 1) ? candidate.dx : -candidate.dx;
                        double sy = (mask & 2) ? candidate.dy : -candidate.dy;
                        double sz = (mask & 4) ? candidate.dz : -candidate.dz;
                        double sw = (mask & 8) ? candidate.dw : -candidate.dw;
                        
                        double tx = thread_optimized_drift.cumulative_x + sx;
                        double ty = thread_optimized_drift.cumulative_y + sy;
                        double tz = thread_optimized_drift.cumulative_z + sz;
                        double tw = thread_optimized_drift.cumulative_w + sw;
                        
                        double sq_dist = tx*tx + ty*ty + tz*tz + tw*tw;
                        if (sq_dist < best_sq_displacement) {
                            best_sq_displacement = sq_dist;
                            best_step = { sx, sy, sz, sw };
                        }
                    }
                }
                
                thread_optimized_drift.cumulative_x += best_step.dx;
                thread_optimized_drift.cumulative_y += best_step.dy;
                thread_optimized_drift.cumulative_z += best_step.dz;
                thread_optimized_drift.cumulative_w += best_step.dw;
                
                results_bound[idx] = std::sqrt(static_cast<double>(p));
                results_opt_drift[idx] = thread_optimized_drift.compute_net_displacement();
                results_std_drift[idx] = thread_standard_drift.compute_net_displacement();
                results_status[idx] = (results_opt_drift[idx] <= results_bound[idx] ? "SAFE" : "OVER");
            }

            size_t current_count = ++progress_counter;
            if (current_count % 5000 == 0 || current_count == total_primes) {
                #pragma omp critical
                {
                    auto now = std::chrono::high_resolution_clock::now();
                    double duration = std::chrono::duration<double>(now - start_time).count();
                    double velocity = current_count / (duration > 0 ? duration : 1.0);
                    double percentage = (static_cast<double>(current_count) / total_primes) * 100.0;
                    
                    std::cout << "\r[PROGRESS] " << std::fixed << std::setprecision(1) 
                              << percentage << "% completed | Processing Speed: " 
                              << std::setprecision(0) << velocity << " primes/sec..." << std::flush;
                }
            }
        }
    } 
    
    std::cout << "\n[SYSTEM] Writing metrics to disk..." << std::endl;
    std::ofstream csv_file("output/mertens_drift_1M_res.csv");
    csv_file << "Prime,Std_Drift,Opt_Drift,Spectral_Bound,Status\n";
    
    for (size_t i = 0; i < total_primes; ++i) {
        csv_file << test_primes[i] << "," << results_std_drift[i] << "," << results_opt_drift[i] << "," << results_bound[i] << "," << results_status[i] << "\n";
    }
    csv_file.close();
    
    auto end_time = std::chrono::high_resolution_clock::now();
    double final_duration = std::chrono::duration<double>(end_time - start_time).count();
    
    std::cout << "──────────────────────────────────────────────────────────" << std::endl;
    std::cout << "[COMPLETE] Calculated 1M Space Walk in " << std::fixed << std::setprecision(2) << final_duration << " seconds." << std::endl;
    std::cout << "[OUTPUT] Matrices exported to: 'output/mertens_drift_1M_res.csv'" << std::endl;
    std::cout << "──────────────────────────────────────────────────────────" << std::endl;
    
    return 0;
}
